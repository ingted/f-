﻿// 了解更多关于 F# 的信息，请访问 https://fsharp.org
// 请参阅“F# 教程”项目以获取更多帮助。

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // 返回整数退出代码
