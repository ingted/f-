﻿// F# の詳細については、https://fsharp.org をご覧ください
// 詳細については、'F# チュートリアル' プロジェクトを参照してください。

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // 整数の終了コードを返します
