﻿// Weitere Informationen zu F# unter https://fsharp.org.
// Weitere Hilfe finden Sie im Projekt "F#-Tutorial".

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // Integer-Exitcode zurückgeben
