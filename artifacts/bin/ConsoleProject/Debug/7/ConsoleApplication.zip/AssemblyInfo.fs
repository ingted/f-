﻿namespace $safeprojectname$.AssemblyInfo

open System.Reflection
open System.Runtime.CompilerServices
open System.Runtime.InteropServices

// Allgemeine Informationen über eine Assembly werden über die folgende
// Attributgruppe gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
// die einer Assembly zugeordnet sind.
[<assembly: AssemblyTitle("$projectname$")>]
[<assembly: AssemblyDescription("")>]
[<assembly: AssemblyConfiguration("")>]
[<assembly: AssemblyCompany("$registeredorganization$")>]
[<assembly: AssemblyProduct("$projectname$")>]
[<assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")>]
[<assembly: AssemblyTrademark("")>]
[<assembly: AssemblyCulture("")>]

// Durch Festlegen von ComVisible auf FALSE sind die Typen in dieser Assembly nicht
// für COM-Komponenten sichtbar. Wenn Sie auf einen Typ in dieser Assembly von
// COM aus zugreifen müssen, sollten Sie das ComVisible-Attribut für diesen Typ auf TRUE festlegen.
[<assembly: ComVisible(false)>]

// Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
[<assembly: Guid("$guid1$")>]

// Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
//
//       Hauptversion
//       Nebenversion
//       Buildnummer
//       Revision
//
// Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern
// übernehmen, indem Sie "*" eingeben:
// [<assembly: AssemblyVersion("1.0.*")>]
[<assembly: AssemblyVersion("1.0.0.0")>]
[<assembly: AssemblyFileVersion("1.0.0.0")>]

do
    ()