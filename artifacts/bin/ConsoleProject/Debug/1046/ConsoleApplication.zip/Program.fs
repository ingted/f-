﻿// Saiba mais sobre o F# em https://fsharp.org
// Veja o projeto 'F# Tutorial' para obter mais ajuda.

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // retornar um código de saída inteiro
