﻿// F# hakkında daha fazla bilgi edinmek için bkz. https://fsharp.org
// Daha fazla yardım almak için 'F# Öğreticisi' projesine göz atın.

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // bir tamsayı çıkış kodu döndürür
