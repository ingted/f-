﻿namespace $safeprojectname$.AssemblyInfo

open System.Reflection
open System.Runtime.CompilerServices
open System.Runtime.InteropServices

// Bir bütünleştirilmiş koda ilişkin Genel Bilgiler aşağıdaki
// öznitelikler kümesi. Bilgileri değiştirmek için bu öznitelik değerlerini değiştirin
// Bir bütünleştirilmiş kod ile ilişkilendirildi.
[<assembly: AssemblyTitle("$projectname$")>]
[<assembly: AssemblyDescription("")>]
[<assembly: AssemblyConfiguration("")>]
[<assembly: AssemblyCompany("$registeredorganization$")>]
[<assembly: AssemblyProduct("$projectname$")>]
[<assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")>]
[<assembly: AssemblyTrademark("")>]
[<assembly: AssemblyCulture("")>]

// ComVisible ayarının false olarak belirlenmesi bu derlemedeki türleri
// COM bileşenlerine görünmez yapar.  Bu derlemedeki bir türe COM'dan
// erişmeniz gerekirse ComVisible özniteliğini o türde true olarak ayarlayın.
[<assembly: ComVisible(false)>]

// Eğer bu proje COM'a maruz kaldıysa aşağıdaki GUID typelib'in IDsi içindir
[<assembly: Guid("$guid1$")>]

// Bir derlemenin sürüm bilgileri aşağıdaki dört değerden oluşur:
//
//       Birincil Sürüm
//       İkincil Sürüm
//       Yapı Numarası
//       Düzeltme
//
// Tüm değerleri belirtebilir veya varsayılan Oluşturma ve Düzeltme Numaralarını kullanabilirsiniz
// '*' karakterini aşağıda gösterildiği gibi kullanarak:
// [<assembly: AssemblyVersion("1.0.*")>]
[<assembly: AssemblyVersion("1.0.0.0")>]
[<assembly: AssemblyFileVersion("1.0.0.0")>]

do
    ()