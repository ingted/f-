﻿namespace $safeprojectname$.AssemblyInfo

open System.Reflection
open System.Runtime.CompilerServices
open System.Runtime.InteropServices

// Ogólne informacje o zestawie są kontrolowane poprzez następujący
// zbiór atrybutów. Zmień wartości tych atrybutów by zmodyfikować informacje
// powiązane z zestawem.
[<assembly: AssemblyTitle("$projectname$")>]
[<assembly: AssemblyDescription("")>]
[<assembly: AssemblyConfiguration("")>]
[<assembly: AssemblyCompany("$registeredorganization$")>]
[<assembly: AssemblyProduct("$projectname$")>]
[<assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")>]
[<assembly: AssemblyTrademark("")>]
[<assembly: AssemblyCulture("")>]

// Ustawienie wartości ComVisible na false sprawia, że typy w tym zestawie nie będą widoczne
// dla składników COM.  Jeśli potrzebny jest dostęp do typu w tym zestawie z
// COM, ustaw atrybut ComVisible na true dla danego typu.
[<assembly: ComVisible(false)>]

// Następujący GUID jest dla ID typelib jeśli ten projekt jest dostępny dla COM
[<assembly: Guid("$guid1$")>]

// Informacje o wersji zestawu zawierają następujące cztery wartości:
//
//       Wersja główna
//       Wersja pomocnicza
//       Numer kompilacji
//       Poprawka
//
// Można określać wszystkie wartości lub używać domyślnych numerów kompilacji i poprawki
// przy użyciu symbolu „*”, tak jak pokazano poniżej:
// [<assembly: AssemblyVersion("1.0.*")>]
[<assembly: AssemblyVersion("1.0.0.0")>]
[<assembly: AssemblyFileVersion("1.0.0.0")>]

do
    ()