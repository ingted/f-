﻿// Dowiedz się więcej o języku F# na stronie https://fsharp.org
// Aby uzyskać dodatkową pomoc, zobacz projekt „Samouczek języka F#”.

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // zwracanie kodu zakończenia w postaci liczby całkowitej
