﻿// Más información sobre F# en https://fsharp.org
// Vea el proyecto "Tutorial de F#" para obtener más ayuda.

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // devolver un código de salida entero
