﻿// https://fsharp.org에서 F#에 대해 자세히 알아보기
// 자세한 도움말은 'F# 자습서' 프로젝트를 참조하세요.

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // 정수 종료 코드 반환
