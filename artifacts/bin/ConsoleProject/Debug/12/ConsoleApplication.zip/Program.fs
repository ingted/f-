﻿// En savoir plus sur F# : https://fsharp.org
// Voir le projet 'Didacticiel F#' pour obtenir de l'aide.

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // retourne du code de sortie entier
