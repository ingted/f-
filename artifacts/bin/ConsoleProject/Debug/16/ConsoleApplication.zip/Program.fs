﻿// Altre informazioni su F# disponibili all'indirizzo https://fsharp.org
// Per altre informazioni, vedere il progetto 'Esercitazione su F#'.

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // restituisce un intero come codice di uscita
