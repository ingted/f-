﻿// 前往 https://fsharp.org 深入了解 F#
// 請參閱「F# 教學課程」專案，取得更多說明。

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // 傳回整數的結束代碼
