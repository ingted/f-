﻿// Další informace o F# najdete na https://fsharp.org.
// Pokud potřebujete další nápovědu, viz projekt Výukový kurz F#.

[<EntryPoint>]
let main argv =
    printfn "%A" argv
    0 // vrátit celočíselný ukončovací kód
