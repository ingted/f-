﻿namespace $safeprojectname$.AssemblyInfo

open System.Reflection
open System.Runtime.CompilerServices
open System.Runtime.InteropServices

// Obecné informace o sestavení se řídí přes následující
// sadu atributů. Změnou hodnot těchto atributů se upraví informace
// přidružené k sestavení.
[<assembly: AssemblyTitle("$projectname$")>]
[<assembly: AssemblyDescription("")>]
[<assembly: AssemblyConfiguration("")>]
[<assembly: AssemblyCompany("$registeredorganization$")>]
[<assembly: AssemblyProduct("$projectname$")>]
[<assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")>]
[<assembly: AssemblyTrademark("")>]
[<assembly: AssemblyCulture("")>]

// Nastavením atributu ComVisible na hodnotu False budou typy v tomto sestavení neviditelné
// pro komponenty modelu COM.  Pokud potřebujete přistoupit k typu v tomto sestavení z
// modelu COM, nastavte atribut ComVisible daného typu na hodnotu True.
[<assembly: ComVisible(false)>]

// Následující GUID se používá pro ID knihovny typů, pokud je tento projekt vystavený pro COM.
[<assembly: Guid("$guid1$")>]

// Informace o verzi sestavení se skládá z těchto čtyř hodnot:
//
//       Hlavní verze
//       Podverze
//       Číslo sestavení
//       Revize
//
// Můžete zadat všechny hodnoty nebo nechat nastavená výchozí čísla sestavení a revize
// pomocí zástupného znaku * takto:
// [<assembly: AssemblyVersion("1.0.*")>]
[<assembly: AssemblyVersion("1.0.0.0")>]
[<assembly: AssemblyFileVersion("1.0.0.0")>]

do
    ()